import { z } from 'zod';
import { QuestionType, DiscursiveAssessment, QuizMode } from '../types/index.js';

// ==========================================
// SCHEMAS DE AUTENTICAÇÃO
// ==========================================

export const registerUserSchema = z.object({
  name: z.string().min(2, 'O nome deve ter no mínimo 2 caracteres').max(100),
  email: z.string().email('Email inválido'),
  password: z.string().min(6, 'A senha deve ter no mínimo 6 caracteres'),
  timezone: z.string().default('America/Sao_Paulo')
});

export const loginUserSchema = z.object({
  email: z.string().email('Email inválido'),
  password: z.string().min(1, 'A senha é obrigatória')
});

// ==========================================
// SCHEMAS DE CONTEÚDO
// ==========================================

export const createFocusSchema = z.object({
  name: z.string().min(1, 'O nome do foco é obrigatório').max(100),
  description: z.string().max(500).optional().nullable(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Cor hexadecimal inválida').optional().nullable()
});

export const updateFocusSchema = createFocusSchema.partial();

export const createSubjectSchema = z.object({
  focusId: z.string().uuid('ID de foco inválido'),
  name: z.string().min(1, 'O nome da matéria é obrigatório').max(100),
  description: z.string().max(500).optional().nullable()
});

export const updateSubjectSchema = createSubjectSchema.omit({ focusId: true }).partial();

export const questionOptionSchema = z.object({
  id: z.string().uuid().optional(),
  text: z.string().min(1, 'O texto da alternativa é obrigatório'),
  isCorrect: z.boolean(),
  orderIndex: z.number().int().nonnegative()
});

export const baseQuestionSchema = z.object({
  subjectId: z.string().uuid('ID de matéria inválido'),
  type: z.nativeEnum(QuestionType),
  statement: z.string().min(3, 'O enunciado deve ter no mínimo 3 caracteres'),
  explanation: z.string().optional().nullable(),
  expectedAnswer: z.string().optional().nullable(),
  options: z.array(questionOptionSchema).optional()
});

export const createQuestionSchema = baseQuestionSchema.refine(data => {
  if (data.type === QuestionType.MULTIPLE_CHOICE) {
    if (!data.options || data.options.length < 2) return false;
    const correctCount = data.options.filter(o => o.isCorrect).length;
    return correctCount === 1; // Exatamente uma correta
  }
  if (data.type === QuestionType.DISCURSIVE) {
    return Boolean(data.expectedAnswer || data.explanation);
  }
  return true;
}, {
  message: 'Para múltipla escolha, forneça no mínimo 2 opções e exatamente 1 correta. Para discursiva, forneça a resposta esperada ou justificativa.'
});

export const updateQuestionSchema = baseQuestionSchema.omit({ subjectId: true }).partial();

// ==========================================
// SCHEMAS DE SESSÃO E TENTATIVAS
// ==========================================

export const quizSessionSchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid().optional(),
  mode: z.nativeEnum(QuizMode),
  totalQuestions: z.number().int().nonnegative(),
  totalCorrect: z.number().int().nonnegative(),
  totalIncorrect: z.number().int().nonnegative(),
  durationSeconds: z.number().int().nonnegative(),
  startedAt: z.string().datetime(),
  finishedAt: z.string().datetime().optional().nullable()
});

export const questionAttemptSchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid().optional(),
  questionId: z.string().uuid(),
  quizSessionId: z.string().uuid().optional().nullable(),
  isCorrect: z.boolean(),
  selectedOptionId: z.string().uuid().optional().nullable(),
  discursiveAssessment: z.nativeEnum(DiscursiveAssessment).optional().nullable(),
  timeSpentSeconds: z.number().int().nonnegative(),
  clientStudyDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Formato de data civil inválido (esperado YYYY-MM-DD)'),
  clientTimezone: z.string().optional().nullable(),
  clientCreatedAt: z.string().datetime()
});

export const syncPushPayloadSchema = z.object({
  sessions: z.array(quizSessionSchema),
  attempts: z.array(questionAttemptSchema)
});
