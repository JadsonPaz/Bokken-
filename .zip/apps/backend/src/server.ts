import express from 'express';
import cors from 'cors';
import { env } from './config/env.js';
import { healthRouter } from './routes/health.js';
import { authRouter } from './routes/auth.js';
import { errorHandler } from './middlewares/errorHandler.js';
import { APP_NAME } from '@bokken/shared';

export function createApp() {
  const app = express();

  app.use(cors({
    origin: env.CORS_ORIGIN,
    credentials: true
  }));

  app.use(express.json());

  // Rotas da API
  app.use('/api', healthRouter);
  app.use('/api/auth', authRouter);

  // Middleware de Tratamento Centralizado de Erros
  app.use(errorHandler);

  return app;
}

export const app = createApp();

export const server = app.listen(env.PORT, () => {
  console.log(`🚀 [${APP_NAME}] Backend rodando em http://localhost:${env.PORT}`);
  console.log(`📡 Ambiente: ${env.NODE_ENV}`);
});

export default app;
