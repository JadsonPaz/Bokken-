import React from 'react';
import { useAuth } from '../context/AuthContext.js';
import { BookOpen, LogOut, Wifi, WifiOff, User, Globe, Sparkles, FolderKanban, BrainCircuit, BarChart3 } from 'lucide-react';
import { APP_NAME } from '@bokken/shared';

export const DashboardPage: React.FC = () => {
  const { user, logout, isOnline } = useAuth();

  return (
    <div className="min-h-screen bg-bokken-surface-soft flex flex-col justify-between">
      {/* Header com Navegação e Perfil */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-bokken-navy flex items-center justify-center text-white shadow-sm">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-bold text-lg text-bokken-navy tracking-tight">{APP_NAME}</h1>
              <span className="text-xs text-slate-500 font-medium">Painel do Estudante</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Indicador de Conectividade / Modo Offline */}
            <div
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
                isOnline
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : 'bg-amber-50 text-amber-800 border-amber-200'
              }`}
            >
              {isOnline ? (
                <>
                  <Wifi className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-amber-600" />
                  <span>Modo Offline</span>
                </>
              )}
            </div>

            {/* Botão de Logout */}
            <button
              onClick={logout}
              title="Sair da conta"
              className="p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <main className="max-w-5xl mx-auto px-4 py-8 flex-1 w-full space-y-8">
        {/* Banner de Boas-vindas com Identidade do Usuário */}
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-blue-50 text-bokken-navy text-xs font-semibold mb-3 border border-blue-100">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              Sessão Autenticada com Sucesso
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
              Olá, {user?.name}!
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Seu ambiente pessoal de estudos está pronto e configurado para operar online e offline.
            </p>
          </div>

          <div className="flex flex-col gap-1 text-xs text-slate-500 bg-slate-50 p-4 rounded-xl border border-slate-100 shrink-0">
            <div className="flex items-center gap-2">
              <User className="w-3.5 h-3.5 text-slate-400" />
              <span>{user?.email}</span>
            </div>
            <div className="flex items-center gap-2">
              <Globe className="w-3.5 h-3.5 text-slate-400" />
              <span>{user?.timezone}</span>
            </div>
          </div>
        </div>

        {/* Grade de Seções (Preparadas para as próximas etapas) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm opacity-90">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-bokken-navy-accent flex items-center justify-center mb-4">
              <FolderKanban className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-slate-900 mb-1">Focos & Matérias</h3>
            <p className="text-xs text-slate-500 mb-4">
              Organize seus conteúdos por objetivos (Concursos, ENEM, Faculdade) e matérias de estudo.
            </p>
            <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-600">
              Próxima Etapa (Etapa 3)
            </span>
          </div>

          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm opacity-90">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-bokken-pine flex items-center justify-center mb-4">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-slate-900 mb-1">Quizzes & Flashcards</h3>
            <p className="text-xs text-slate-500 mb-4">
              Sessões com animação 3D de flip e repetição espaçada ponderada por taxa de erro.
            </p>
            <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-600">
              Etapa 5
            </span>
          </div>

          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm opacity-90">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center mb-4">
              <BarChart3 className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-slate-900 mb-1">Desempenho & Ofensiva</h3>
            <p className="text-xs text-slate-500 mb-4">
              Calendário estilo GitHub Contributions e estatísticas acumuladas offline/online.
            </p>
            <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-600">
              Etapa 6
            </span>
          </div>
        </div>
      </main>

      {/* Rodapé Minimalista */}
      <footer className="border-t border-slate-200 py-6 bg-white text-center text-xs text-slate-400">
        Bokken Estudos &copy; {new Date().getFullYear()} — Sessão de {user?.name}
      </footer>
    </div>
  );
};
